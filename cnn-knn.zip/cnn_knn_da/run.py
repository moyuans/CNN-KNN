import data_generation
import general
import cnn_train
import cnn_test
import abs
from scipy.stats.stats import pearsonr
import numpy as np
import math
from sklearn.neighbors import KNeighborsClassifier
from scipy import misc
from sklearn.metrics import mean_squared_error

import csv
import copy

from PIL import Image

entireImage = '/Users/sunmoyuan1/Desktop/original_jpeg/'
boundary = '/Users/sunmoyuan1/Desktop/wells/'
coordinate = '/Users/sunmoyuan1/Desktop/coordinate/c'

uImages = '/Users/sunmoyuan1/Desktop/u_jpeg/previous/'
uboundary = '/Users/sunmoyuan1/Desktop/n_wells/previous/'


def gt_init(numberOfImages, entireImage, boundary, coordinate, number):
    trainSetData, trainSetCountLabel, allBound = data_generation.generateTrainSetBalanced(entireImage, boundary, coordinate, numberOfImages)
    trainD, trainL, bound = general.balanceNum(number, trainSetData, trainSetCountLabel, allBound)

    return trainD, trainL, bound

def ud_init(numberOfImages, uImages, uboundary):
    td, btd = data_generation.generateSetBalanced(uImages, uboundary, numberOfImages)
    tld = np.zeros(len(td))

    return td, tld, btd

def getThreshold(Data, Label): #switch for ground_truth

    y_true, y_pred, wrongID = cnn_test.use_CNN(Data, Label, 'linear_count_params.pkl','linear_count', False)
    pearson = pearsonr(y_true, y_pred)
    rmse = math.sqrt(mean_squared_error(y_pred,y_true))
    accuracy = (len(y_true) - len(wrongID))/len(y_true)

    return pearson, rmse,accuracy

def getAbs(Data, Label):
    y_abs = abs.abs(Data, Label, 'linear_count_params.pkl', 'linear_count')

    return y_abs

def getTrainData_new(neighbours, trainD, uD, trainL, bound, ubound, abs_t, abs_u, number_add, confidence_threshold):
    knn = KNeighborsClassifier(n_neighbors=neighbours)
    x1 = abs_t
    x1_b = bound
    y1 = trainL

    knn.fit(x1, y1)

    x2 = abs_u
    x2_b = ubound
    #print('abs_u length is: ' + str(len(x2)))

    y2 = knn.predict(x2)
    prob = knn.predict_proba(x2)
    #print('abs_u_y length is: ' + str(len(y2)))

    td = []
    tdy = []
    tboundary = []

    utd = []
    utdy = []
    utboundary = []
    for j in range(len(y2)):
        if max(prob[j]) > confidence_threshold:
            td.append(uD[j])
            tdy.append(y2[j])
            tboundary.append(x2_b[j])
        else:
            utd.append(uD[j])
            utdy.append(y2[j])
            utboundary.append(x2_b[j])

    #print('td length is: ' + str(len(td)))
    # utd not have those for sure but not included in the final balance set
    #print('utd length is: ' + str(len(utd)))


    general.timeSeries(x1_b, tboundary, trainL, tdy)

    balance = general.countLabel(tdy)


    if balance < number_add:
        x_add, y_add, b_add, restSet,restSetLabel,restBound = general.balanceNumAdd_all(balance, td, tdy, tboundary)
    else:
        x_add, y_add, b_add, restSet,restSetLabel,restBound = general.balanceNumAdd_all(number_add, td, tdy, tboundary)
        print(len(x_add))

    trainS_rgbs = []
    trainC_aug = []
    trainW_aug = []

    for i in range(len(x_add)):
        tdi = np.asarray(x_add[i]).reshape(53, 53)
        path = '/Users/sunmoyuan1/Desktop/check/' + str(i) + '.jpeg'
        misc.imsave(path,tdi)

        im = Image.open(path)
        datai, labeli, boundi = data_generation.ImgAug10G(im, y_add[i], b_add[i])
        for j in range(len(datai)):
            trainS_rgbs.append(datai[j])
            trainC_aug.append(labeli[j])
            trainW_aug.append(boundi[j])

    print(len(trainD), len(trainL), len(x1_b))
    print(len(trainS_rgbs), len(trainW_aug), len(trainC_aug))

    trainD1, trainL1, bound1 = general.concatDataWithBoundary(trainD, trainS_rgbs, trainL, trainC_aug, x1_b, trainW_aug)
    print(len(trainD1))

    if len(restSet) != 0:
        utd, utdy, utboundary = general.concatDataWithBoundary(utd, restSet, utdy, restSetLabel, utboundary, restBound) #except the labelled ones for UL

    return trainD1, trainL1, bound1, utd, utdy, utboundary, balance


iteration_limit = 5
K_nearest_neighbours = 5
confidence_threshold = 0.7
balanceNum = 5

train, test = data_generation.generateRandom()

[trainD, trainL, bound] = train
[testD, testL, testbound] = test

ud, uld, ubound = ud_init([1, 12], uImages, uboundary)

trainS, trainC, trainW = data_generation.balanceRandom(trainD, trainL, bound, 20)

trainS_rgb = []
#trainS_rgbs = []
#trainC_aug = []
#trainW_aug = []
for i in range(len(trainS)):
    trainS_rgb.append(data_generation.imgToArray(trainS[i]))
    #datai, labeli, boundi = data_generation.ImgAug10(trainS[i], trainC[i], trainW[i])
    #for j in range(len(datai)):
        #trainS_rgbs.append(datai[j])
        #trainC_aug.append(labeli[j])
        #trainW_aug.append(boundi[j])


testD_rgb = []
for i in range(len(testD)):
    testD_rgb.append(data_generation.imgToArray(testD[i]))

cnn_train.train_CNN(53, 53, 5000, 'linear_count', trainS_rgb, trainC, 0.00001)
pearson, rmse, accuracy = getThreshold(testD_rgb, testL)
print(pearson, rmse, accuracy)


train_abs = getAbs(trainS_rgb, trainC)
u_abs = getAbs(ud, uld)

count = 0
while count < iteration_limit:
    trainS_rgb, trainC, trainW, utd1, utdy1, ubound, balance = getTrainData_new(K_nearest_neighbours, trainS_rgb, ud, trainC, trainW, ubound,
                                                                           train_abs, u_abs, balanceNum, confidence_threshold)

    cnn_train.train_CNN(53, 53, 5000, 'linear_count', trainS_rgb, trainC, 0.000005)
    pearson1, rmse1, accuracy1 = getThreshold(testD_rgb, testL)
    print(pearson1, rmse1, accuracy1)

    print('start')
    print(len(trainS_rgb))
    print(len(utd1))
    print('end')

    train_abs = getAbs(trainS_rgb, trainC)
    u_abs = getAbs(utd1, utdy1)
    count = count + 1

pearson, rmse, accuracy = getThreshold(testD_rgb, testL)

print(pearson, rmse, accuracy)



