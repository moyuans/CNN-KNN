import data_generation
import general
import cnn_train
from scipy.stats.stats import pearsonr
import cnn_test
import math
from sklearn.metrics import mean_squared_error

import pylab
import matplotlib.pyplot as plt

entireImage = '/Users/sunmoyuan1/Desktop/original_jpeg/'
boundary = '/Users/sunmoyuan1/Desktop/wells/'
coordinate = '/Users/sunmoyuan1/Desktop/coordinate/c'


def ScatterFig(predict, true, number, title):
    pylab.rcParams['figure.figsize'] = (10.0, 10.0)
    img = plt.scatter(true, predict, color='black')
    plt.ylabel('Predicted Number Of Cells')
    plt.xlabel('True Number Of Cells')
    plt.title(title)
    plt.axis('on')
    fig = plt.gcf()

    fig.savefig('/Users/sunmoyuan1/Desktop/' + str(number) + '.png', dpi=100)
    plt.show(img)

def gt_init(numberOfImages, entireImage, boundary, coordinate, number):
    trainSetData, trainSetCountLabel, allBound = data_generation.generateTrainSetBalanced(entireImage, boundary, coordinate, numberOfImages)
    trainD, trainL, bound = general.balanceNum(number, trainSetData, trainSetCountLabel, allBound)

    return trainD, trainL, bound

def getThreshold(Data, Label):

    y_true, y_pred, wrongID = cnn_test.use_CNN(Data, Label, 'linear_count_params.pkl','linear_count', False)
    pearson = pearsonr(y_true, y_pred)
    rmse = math.sqrt(mean_squared_error(y_pred,y_true))
    accuracy = (len(y_true) - len(wrongID))/len(y_true)

    return pearson, rmse, accuracy


def getThreshold2(Data, Label, number, title):

    y_true, y_pred, wrongID = cnn_test.use_CNN(Data, Label, 'linear_count_params.pkl','linear_count', False)
    ScatterFig(y_pred, y_true, number, title)
    pearson = pearsonr(y_true, y_pred)
    rmse = math.sqrt(mean_squared_error(y_pred,y_true))
    accuracy = (len(y_true) - len(wrongID))/len(y_true)

    return pearson, rmse,accuracy

trainD, trainL, bound = data_generation.generateTrainP(entireImage, boundary, coordinate, [1,6])
trainD, trainL, bound = general.balanceNum(15, trainD, trainL, bound) # balanceNum(n, trainD, trainL, bound), change n to get 2 * n data for training
testD, testL, testbound = gt_init([7,12], entireImage, boundary, coordinate, 500)

'''
train, test = data_generation.generateRandom()

[trainD, trainL, bound] = train
[testD, testL, testbound] = test
'''

trainD_rgb = []
trainD_rgbs = []
trainL_aug = []
bound_aug = []
for i in range(len(trainD)):
    trainD_rgb.append(data_generation.imgToArray(trainD[i]))
    datai, labeli, boundi = data_generation.ImgAug10(trainD[i], trainL[i], bound[i]) # change ImgAug10() to ImgAug10G to get *100 image agmentation
    for j in range(len(datai)):
        trainD_rgbs.append(datai[j])
        trainL_aug.append(labeli[j])
        bound_aug.append(boundi[j])


'''
trainS, trainC, trainW = data_generation.balanceRandom(trainD, trainL, bound, 20)
print(len(trainS))

trainS_rgb = []
trainS_rgbs = []
trainC_aug = []
trainW_aug = []
for i in range(len(trainS)):
    trainS_rgb.append(data_generation.imgToArray(trainS[i]))
    datai, labeli, boundi = data_generation.ImgAug10(trainS[i], trainC[i], trainW[i])
    for j in range(len(datai)):
        trainS_rgbs.append(datai[j])
        trainC_aug.append(labeli[j])
        trainW_aug.append(boundi[j])


testD_rgb = []
for i in range(len(testD)):
    testD_rgb.append(data_generation.imgToArray(testD[i]))
'''


"""
get Pearson correlation, rmse, accuracy for original train dataset
and
*10 image or *100 image augmentation method
"""

cnn_train.train_CNN(54, 54, 5000, 'linear_count', trainD_rgb, trainL, 0.000005)
pearson, rmse, accuracy = getThreshold2(testD, testL, 30, 'CNN only')


cnn_train.train_CNN(54, 54, 5000, 'linear_count', trainD_rgbs, trainL_aug, 0.000005)
pearson1, rmse1, accuracy1 = getThreshold2(testD, testL, 330, '*10 method')


print()
print('Original Pearson, RMSE, accurracy is: ')
print(pearson[0], rmse, accuracy)
print()
print('*10 or *100 augmentation method Pearson, RMSE, accurracy is: ')
print(pearson1[0], rmse1, accuracy1)
