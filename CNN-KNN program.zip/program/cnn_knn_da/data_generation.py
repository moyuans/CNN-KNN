import csv
import numpy as np
from scipy import misc
from PIL import Image, ImageFilter
import random
import general


def loadEntireImage(entire_path):
    img = Image.open(entire_path)
    return img

#get boundary of a well from csv
def loadBoundary(ai):
    oneTest = ai
    x1 = 0
    y1 = 0
    x = round(float(oneTest[0]))
    y = round(float((oneTest[1])))
    w = round(float((oneTest[2])))
    h = round(float((oneTest[3])))

    if x + 54 <= 1080 and y + 54 <= 1280:
        x1 = x + 54
        y1 = y + 54  # fix well size to get trainSetData balanced, size for an array in it

    return ([x, y, x1, y1])


# get boundary of wells for a frame
def loadBoundaryW(path):  # new

    a = []
    csv_reader = csv.reader(open(path))
    for row in csv_reader:
        a.append(row)

    return a


#get coordinates of cells of a frame
def loadCoordinateW(path):  # new

    a = []
    csv_reader = csv.reader(open(path))
    for row in csv_reader:
        a.append(row)

    arrayX = []
    arrayY = []

    for i in range(0, len(a)):
        xc = float(a[i][0])  # or int
        yc = float(a[i][1])

        arrayX.append(xc)
        arrayY.append(yc)

    return arrayX, arrayY


# coordinates of cells for a well in csv in string format
def loadCoordinate(path, bi):
    a = []
    csv_reader = csv.reader(open(path))
    for row in csv_reader:
        a.append(row)

    arrayX = []
    arrayY = []

    x = float(bi[0])
    y = float(bi[1])
    w = float(bi[2])
    h = float(bi[3])

    for i in range(0, len(a)):
        xc = float(a[i][0])
        yc = float(a[i][1])
        if xc > x and xc < x + w:  # need well validation check? or not?
            if yc > y and yc < y + h:
                arrayX.append(xc)
                arrayY.append(yc)

    return arrayX, arrayY


def rgbToInteger(r, g, b):  # no need to get value in M
    return r * 256 * 256 + g * 256 + b


# calculate the label of a well
def countCell(cx):
    return len(cx)


#generate all wells from some annotated frames, the output set is not balanced
def generateTrainSetBalanced(entireImgPath, boundaryPath, coordinatePath, numberOfImage):
    trainData = []
    trainLabelCount = []
    allBound = []

    for imageNumber in range(numberOfImage[0], numberOfImage[1] + 1):
        entireImg = loadEntireImage(entireImgPath + str(imageNumber) + ".jpeg")
        boundaryW = loadBoundaryW(boundaryPath + str(imageNumber) + ".csv")

        for i in range(len(boundaryW)):  # for a single well
            boundary = loadBoundary(boundaryW[i])
            cxx, cyy = loadCoordinate(coordinatePath + str(imageNumber) + ".csv", boundaryW[i])
            img = entireImg.crop(boundary)
            rgb = []
            for k in range(len(img.getdata())):
                rgb.append(rgbToInteger(img.getdata()[k][0], img.getdata()[k][1], img.getdata()[k][2]))

            count = countCell(cxx)

            if boundary[2] != 0:
                trainData.append(rgb)
                trainLabelCount.append(count)
                allBound.append(boundary)

    return trainData, trainLabelCount, allBound


#generate all wells from unlabelled frames
def generateSetBalanced(entireImgPath, boundaryPath, numberOfImage):
    trainData = []
    boundaryC = []

    for imageNumber in range(numberOfImage[0], numberOfImage[1] + 1):
        entireImg = loadEntireImage(entireImgPath + str(imageNumber) + ".jpeg")
        boundaryW = loadBoundaryW(boundaryPath + str(imageNumber) + ".csv")

        for i in range(len(boundaryW)):  # for a single well
            boundary = loadBoundary(boundaryW[i])

            img = entireImg.crop(boundary)
            rgb = []
            for k in range(len(img.getdata())):
                rgb.append(rgbToInteger(img.getdata()[k][0], img.getdata()[k][1], img.getdata()[k][2]))

            if (boundary[2] != 0):
                trainData.append(rgb)
                boundaryC.append(boundary)

    #print(len(trainData))

    return trainData, boundaryC

###################
#image augmentation
###################
def generateTrainP(entireImgPath, boundaryPath, coordinatePath, numberOfImage): #for image directly
    imgs = []
    count = []
    bound = []
    for imageNumber in range(numberOfImage[0], numberOfImage[1] + 1):
        entireImg = loadEntireImage(entireImgPath + str(imageNumber) + ".jpeg")
        boundaryW = loadBoundaryW(boundaryPath + str(imageNumber) + ".csv")

        for i in range(len(boundaryW)):  # for a single well
            boundary = loadBoundary(boundaryW[i])
            if coordinatePath != None:
                cxx, cyy = loadCoordinate(coordinatePath + str(imageNumber) + ".csv", boundaryW[i])

            img = entireImg.crop(boundary)
            if boundary[2] != 0:
                imgs.append(img)
                if coordinatePath != None:
                    countx = countCell(cxx)
                    count.append(countx)
                bound.append(boundary)

    if len(count) != 0:
        return imgs, count, bound
    else:
        return imgs, np.zeros(len(imgs)), bound




def imgToArray(img):
    rgb = []
    for k in range(len(img.getdata())):
        rgb.append(rgbToInteger(img.getdata()[k][0], img.getdata()[k][1], img.getdata()[k][2]))

    return rgb

def imgToArrayG(img):
    rgb = []
    for k in range(len(img.getdata())):
        rgb.append(rgbToInteger(img.getdata()[0],img.getdata()[0],img.getdata()[0]))

    return rgb

def sp_noise(image,prob): #0.3
    data = imgToArray(image)
    output = data
    thres = 1 - prob
    for i in range(len(data)):
        rdn = random.random()
        if rdn < prob:
            output[i] = 0
        elif rdn > thres:
            output[i] = 16777215
        else:
            output[i] = data[i]

    return output

    #return np.reshape(np.asarray(output), 53)

def sp_noiseG(data,prob): #0.3
    output = data
    thres = 1 - prob
    for i in range(len(data)):
        rdn = random.random()
        if rdn < prob:
            output[i] = 0
        elif rdn > thres:
            output[i] = 16777215
        else:
            output[i] = data[i]

    return output

def ImgAug10(img, label, bound):
    data = []

    labels =[]
    bounds = []
    for i in range(11):
        labels.append(label)
        bounds.append(bound)


    data0 = imgToArray(img)
    data.append(data0)

    #path = '/Users/sunmoyuan1/Desktop/'

    #img.save('/Users/sunmoyuan1/Desktop/original.jpeg')

    out1 = img.transpose(Image.FLIP_LEFT_RIGHT)
    #out1.save(path + 'out1.jpeg')
    data1 = imgToArray(out1)
    data.append(data1)



    out2 = img.transpose(Image.FLIP_TOP_BOTTOM)
    #out2.save(path + 'out2.jpeg')
    data2 = imgToArray(out2)
    data.append(data2)

    out3 = img.transpose(Image.ROTATE_90)
    #out3.save(path + 'out3.jpeg')
    data3 = imgToArray(out3)
    data.append(data3)

    out4 = img.transpose(Image.ROTATE_180)
    #out4.save(path + 'out4.jpeg')
    data4 = imgToArray(out4)
    data.append(data4)

    out5 = img.transpose(Image.ROTATE_270)
    #out5.save(path + 'out5.jpeg')
    data5 = imgToArray(out5)
    data.append(data5)

    out6 = img.filter(ImageFilter.GaussianBlur(radius=0.5))
    #out6.save(path + 'out6.jpeg')
    data6 = imgToArray(out6)
    data.append(data6)

    out7 = img.filter(ImageFilter.GaussianBlur(radius=1))
    #out7.save(path + 'out7.jpeg')
    data7 = imgToArray(out7)
    data.append(data7)

    data8 = sp_noise(img,0.001)
    #td8 = np.asarray(data8).reshape(53, 53)
    #path = '/Users/sunmoyuan1/Desktop/out8.jpeg'
    #misc.imsave(path, td8)
    data.append(data8)

    data9 = sp_noise(img,0.002)
    #td9 = np.asarray(data9).reshape(53, 53)
    #path = '/Users/sunmoyuan1/Desktop/out9.jpeg'
    #misc.imsave(path, td9)
    data.append(data9)

    data10 = sp_noise(img, 0.003)
    #td10 = np.asarray(data10).reshape(53, 53)
    #path = '/Users/sunmoyuan1/Desktop/out10.jpeg'
    #misc.imsave(path, td10)
    data.append(data10)

    return data, labels, bounds


def ImgAug100(img, label, bound):
    data = []

    labels =[]
    bounds = []

    for i in range(101):
        labels.append(label)
        bounds.append(bound)


    data0 = imgToArray(img)
    data.append(data0)

    #path = '/Users/sunmoyuan1/Desktop/'

    #img.save('/Users/sunmoyuan1/Desktop/original.jpeg')

    out1 = img.transpose(Image.FLIP_LEFT_RIGHT)
    #out1.save(path + 'out1.jpeg')
    data1 = imgToArray(out1)
    data.append(data1)



    out2 = img.transpose(Image.FLIP_TOP_BOTTOM)
    #out2.save(path + 'out2.jpeg')
    data2 = imgToArray(out2)
    data.append(data2)

    out3 = img.transpose(Image.ROTATE_90)
    #out3.save(path + 'out3.jpeg')
    data3 = imgToArray(out3)
    data.append(data3)

    out4 = img.transpose(Image.ROTATE_180)
    #out4.save(path + 'out4.jpeg')
    data4 = imgToArray(out4)
    data.append(data4)

    out5 = img.transpose(Image.ROTATE_270)
    #out5.save(path + 'out5.jpeg')
    data5 = imgToArray(out5)
    data.append(data5)

    for i in range(45):
        radiusn = random.random()
        out6 = img.filter(ImageFilter.GaussianBlur(radius=radiusn))
        #out6.save(path + 'out6.jpeg')
        data6 = imgToArray(out6)
        data.append(data6)

    for j in range(50):
        probability = random.random()/100
        data7 = sp_noise(img,probability)
        #td7 = np.asarray(data8).reshape(53, 53)
        #path = '/Users/sunmoyuan1/Desktop/out8.jpeg'
        #misc.imsave(path, td7)
        data.append(data7)

    return data, labels, bounds

def ImgAug10G(img, label, bound):
    data = []

    labels =[]
    bounds = []
    for i in range(11):
        labels.append(label)
        bounds.append(bound)


    data0 = imgToArrayG(img)
    data.append(data0)

    #path = '/Users/sunmoyuan1/Desktop/'

    #img.save('/Users/sunmoyuan1/Desktop/original.jpeg')

    out1 = img.transpose(Image.FLIP_LEFT_RIGHT)
    #out1.save(path + 'out1.jpeg')
    data1 = imgToArrayG(out1)
    data.append(data1)



    out2 = img.transpose(Image.FLIP_TOP_BOTTOM)
    #out2.save(path + 'out2.jpeg')
    data2 = imgToArrayG(out2)
    data.append(data2)

    out3 = img.transpose(Image.ROTATE_90)
    #out3.save(path + 'out3.jpeg')
    data3 = imgToArrayG(out3)
    data.append(data3)

    out4 = img.transpose(Image.ROTATE_180)
    #out4.save(path + 'out4.jpeg')
    data4 = imgToArrayG(out4)
    data.append(data4)

    out5 = img.transpose(Image.ROTATE_270)
    #out5.save(path + 'out5.jpeg')
    data5 = imgToArrayG(out5)
    data.append(data5)

    out6 = img.filter(ImageFilter.GaussianBlur(radius=0.5))
    #out6.save(path + 'out6.jpeg')
    data6 = imgToArrayG(out6)
    data.append(data6)

    out7 = img.filter(ImageFilter.GaussianBlur(radius=1))
    #out7.save(path + 'out7.jpeg')
    data7 = imgToArrayG(out7)
    data.append(data7)

    data8 = sp_noiseG(data0,0.001)
    #td8 = np.asarray(data8).reshape(53, 53)
    #path = '/Users/sunmoyuan1/Desktop/out8.jpeg'
    #misc.imsave(path, td8)
    data.append(data8)

    data9 = sp_noiseG(data0,0.002)
    #td9 = np.asarray(data9).reshape(53, 53)
    #path = '/Users/sunmoyuan1/Desktop/out9.jpeg'
    #misc.imsave(path, td9)
    data.append(data9)

    data10 = sp_noiseG(data0, 0.003)
    #td10 = np.asarray(data10).reshape(53, 53)
    #path = '/Users/sunmoyuan1/Desktop/out10.jpeg'
    #misc.imsave(path, td10)
    data.append(data10)

    return data, labels, bounds


def generateRandom():
    entireImage = '/Users/sunmoyuan1/Desktop/original_jpeg/'
    boundary = '/Users/sunmoyuan1/Desktop/wells/'
    coordinate = '/Users/sunmoyuan1/Desktop/coordinate/c'

    trainSetData, trainSetCountLabel, allBound = generateTrainSetBalanced(entireImage, boundary, coordinate, [1, 12])
    trainSetImage, trainSetCountLabel, allBound = generateTrainP(entireImage, boundary, coordinate, [1, 12])

    Train0 = []
    Label0 = []
    Bound0 = []

    Train1 = []
    Label1 = []
    Bound1 = []

    Train2 = []
    Label2 = []
    Bound2 = []

    Train3 = []
    Label3 = []
    Bound3 = []

    Train4 = []
    Label4 = []
    Bound4 = []

    Train5andMore = []
    Label5andMore = []
    Bound5andMore = []

    for i in range(len(trainSetData)):
        if trainSetCountLabel[i] == 0:
            Train0.append(trainSetImage[i])
            Label0.append(trainSetCountLabel[i])
            Bound0.append(allBound[i])
        if trainSetCountLabel[i] == 1:
            Train1.append(trainSetImage[i])
            Label1.append(trainSetCountLabel[i])
            Bound1.append(allBound[i])
        if trainSetCountLabel[i] == 2:
            Train2.append(trainSetImage[i])
            Label2.append(trainSetCountLabel[i])
            Bound2.append(allBound[i])
        if trainSetCountLabel[i] == 3:
            Train3.append(trainSetImage[i])
            Label3.append(trainSetCountLabel[i])
            Bound3.append(allBound[i])
        if trainSetCountLabel[i] == 4:
            Train4.append(trainSetImage[i])
            Label4.append(trainSetCountLabel[i])
            Bound4.append(allBound[i])
        if trainSetCountLabel[i] >= 5:
            Train5andMore.append(trainSetImage[i])
            Label5andMore.append(trainSetCountLabel[i])
            Bound5andMore.append(allBound[i])

    newTrainSetData = []
    newTrainSetCountLabel = []
    newBound = []

    newTestSetData = []
    newTestSetCountLabel = []
    newBound1 = []

    # import random
    # order0 = random.sample(range(len(Train0)),85)
    order0 = [667, 451, 58, 207, 9, 746, 86, 490, 1092, 54, 594, 804, 241, 1070, 1053, 436, 688, 582, 507, 144, 1074,
              381, 546, 1060, 777, 863, 564, 1177, 395, 846, 1046, 1155, 388, 793, 1087, 1015, 157, 837, 444, 160,
              809, 159, 469, 649, 294, 155, 1110, 28, 356, 1062, 41, 352, 7, 550, 871, 379, 387, 47, 606, 233, 592,
              82, 240, 601, 148, 1101, 655, 79, 492, 1171, 4, 738, 984, 146, 693, 478, 847, 1038, 1124, 853, 563, 140,
              705, 765, 427]
    order1 = [148, 199, 120, 179, 215, 59, 219, 110, 58, 162, 92, 102, 231, 8, 16, 156, 11, 145, 166, 210, 222, 220,
              193,
              12, 211, 105, 146, 10, 126, 177, 94, 217, 54, 70, 104, 133, 3, 213, 138, 7, 163, 204, 67, 212, 229, 129,
              1, 108, 150, 230, 28, 60, 144, 32, 13, 137, 132, 45, 21, 48, 206, 23, 122, 164, 196, 71, 38, 81, 64, 97,
              128, 192, 47, 119, 100, 111, 109, 17, 197, 18, 173, 165, 115, 77, 176]
    # random.sample(range(len(Train1)),85)
    order2 = [76, 136, 35, 263, 311, 328, 69, 95, 11, 21, 63, 437, 179, 138, 46, 414, 31, 130, 288, 241, 223, 298, 395,
              355, 472, 474, 15, 341, 403, 228, 147, 426, 205, 408, 416, 312, 322, 244, 163, 377, 218, 465, 119, 453,
              190, 307, 415, 85, 90, 158, 373, 127, 455, 171, 464, 279, 267, 162, 229, 314, 245, 247, 338, 459, 66, 313,
              434, 172, 6, 379, 387, 475, 234, 93, 407, 189, 59, 14, 354, 441, 71, 58, 384, 275, 116]
    # random.sample(range(len(Train2)),85)
    order3 = [89, 88, 98, 92, 2, 78, 128, 20, 12, 132, 80, 123, 62, 26, 57, 10, 41, 0, 39, 71, 9, 121, 100, 69, 60, 15,
              35, 99, 76, 86, 74, 112, 66, 105, 108, 4, 46, 63, 45, 37, 114, 64, 50, 115, 83, 24, 129, 104, 11, 43, 127,
              52, 107, 117, 19, 6, 17, 68, 32, 134, 116, 13, 81, 72, 113, 82, 84, 106, 77, 29, 67, 91, 21, 96, 101, 22,
              131, 87, 119, 94, 44, 42, 33, 48, 90]
    # random.sample(range(len(Train3)),85)
    order4 = [91, 149, 119, 102, 68, 92, 54, 123, 141, 174, 35, 74, 40, 155, 125, 118, 93, 169, 5, 115, 52, 161, 17,
              188,
              73, 20, 36, 145, 182, 100, 69, 168, 192, 78, 84, 112, 104, 23, 186, 160, 7, 87, 25, 103, 122, 18, 76, 147,
              143, 108, 157, 21, 177, 154, 46, 33, 37, 43, 81, 31, 133, 27, 30, 171, 184, 116, 83, 127, 32, 28, 88, 94,
              44, 63, 151, 138, 144, 55, 180, 65, 79, 140, 71, 19, 96]
    # random.sample(range(len(Train4)),85)
    order5 = [64, 1, 136, 155, 108, 191, 156, 63, 95, 22, 97, 78, 131, 114, 171, 115, 190, 25, 72, 80, 180, 168, 159,
              162,
              215, 6, 98, 206, 164, 147, 127, 14, 200, 173, 0, 197, 172, 62, 94, 85, 15, 76, 36, 167, 101, 142, 61, 9,
              27, 184, 170, 135, 37, 83, 212, 119, 29, 73, 54, 117, 32, 145, 189, 202, 57, 5, 152, 49, 208, 100, 71, 50,
              59, 8, 74, 151, 18, 187, 198, 149, 65, 103, 204, 201, 93]
    # random.sample(range(len(Train5andMore)),85)


    for i in range(85):
        if i < 70:
            newTrainSetData.append(Train0[order0[i]])
            newTrainSetCountLabel.append(Label0[order0[i]])
            newBound.append(Bound0[order0[i]])

            newTrainSetData.append(Train1[order1[i]])
            newTrainSetCountLabel.append(Label1[order1[i]])
            newBound.append(Bound1[order1[i]])

            newTrainSetData.append(Train2[order2[i]])
            newTrainSetCountLabel.append(Label2[order2[i]])
            newBound.append(Bound2[order2[i]])

            newTrainSetData.append(Train3[order3[i]])
            newTrainSetCountLabel.append(Label3[order3[i]])
            newBound.append(Bound3[order3[i]])

            newTrainSetData.append(Train4[order4[i]])
            newTrainSetCountLabel.append(Label4[order4[i]])
            newBound.append(Bound4[order4[i]])

            newTrainSetData.append(Train5andMore[order5[i]])
            newTrainSetCountLabel.append(Label5andMore[order5[i]])
            newBound.append(Bound5andMore[order5[i]])

        if i >= 70:
            newTestSetData.append(Train0[order0[i]])
            newTestSetCountLabel.append(Label0[order0[i]])
            newBound1.append(Bound0[order0[i]])

            newTestSetData.append(Train1[order1[i]])
            newTestSetCountLabel.append(Label1[order1[i]])
            newBound1.append(Bound1[order1[i]])


            newTestSetData.append(Train2[order2[i]])
            newTestSetCountLabel.append(Label2[order2[i]])
            newBound1.append(Bound2[order2[i]])

            newTestSetData.append(Train3[order3[i]])
            newTestSetCountLabel.append(Label3[order3[i]])
            newBound1.append(Bound3[order3[i]])

            newTestSetData.append(Train4[order4[i]])
            newTestSetCountLabel.append(Label4[order4[i]])
            newBound1.append(Bound4[order4[i]])

            newTestSetData.append(Train5andMore[order5[i]])
            newTestSetCountLabel.append(Label5andMore[order5[i]])
            newBound1.append(Bound5andMore[order5[i]])

    trainList = [newTrainSetData, newTrainSetCountLabel, newBound]
    testList = [newTestSetData, newTestSetCountLabel, newBound1]


    return trainList, testList

def balanceRandom(trainSet, trainSetCountLabel, bound, number):
    train = []
    label = []
    boundary = []

    count0 = 0
    count1 = 0
    count2 = 0
    count3 = 0
    count4 = 0
    count5 = 0

    for i in range(len(trainSetCountLabel)):
        if trainSetCountLabel[i] == 0 and count0 < number:
            train.append(trainSet[i])
            label.append(trainSetCountLabel[i])
            boundary.append(bound[i])
            count0 = count0 + 1
        if trainSetCountLabel[i] == 1 and count1 < number:
            train.append(trainSet[i])
            label.append(trainSetCountLabel[i])
            boundary.append(bound[i])
            count1 = count1 + 1
        if trainSetCountLabel[i] == 2 and count2 < number:
            train.append(trainSet[i])
            label.append(trainSetCountLabel[i])
            boundary.append(bound[i])
            count2 = count2 + 1
        if trainSetCountLabel[i] == 3 and count3 < number:
            train.append(trainSet[i])
            label.append(trainSetCountLabel[i])
            boundary.append(bound[i])
            count3 = count3 + 1
        if trainSetCountLabel[i] == 4 and count4 < number:
            train.append(trainSet[i])
            label.append(trainSetCountLabel[i])
            boundary.append(bound[i])
            count4 = count4 + 1
        if trainSetCountLabel[i] >= 5 and count5 < number:
            train.append(trainSet[i])
            label.append(trainSetCountLabel[i])
            boundary.append(bound[i])
            count5 = count5 + 1

    return train, label, boundary


















