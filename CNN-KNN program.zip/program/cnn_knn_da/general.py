import pickle
import copy
import numpy as np

def save_paramsList(param_path,paramsList):
        write_file = open(param_path, 'wb')
        pickle.dump(paramsList,write_file,-1)
        write_file.close()

def load_paramsList(params_file):
    f=open(params_file,'rb')
    paramsList=pickle.load(f)
    f.close()
    return paramsList

def load_params(params_file):
    f=open(params_file,'rb')
    layer0_params=pickle.load(f)
    layer1_params=pickle.load(f)
    layer2_params=pickle.load(f)
    layer3_params=pickle.load(f)
    f.close()
    return layer0_params,layer1_params,layer2_params,layer3_params


#get balanced dataset
def balanceNum(balanceNum, trainSetData, trainSetCountLabel, allBound):
    labelledNum = 0
    zeroNum = 0

    balanceSet = []
    balanceSetLabel = []
    bound = []

    for i in range(len(trainSetData)):
        if trainSetCountLabel[i] > 0 and labelledNum < balanceNum:
            labelledNum = labelledNum + 1
            balanceSet.append(trainSetData[i])
            balanceSetLabel.append(trainSetCountLabel[i])
            bound.append(allBound[i])


        if trainSetCountLabel[i] == 0 and zeroNum < balanceNum:
            zeroNum = zeroNum + 1
            balanceSet.append(trainSetData[i])
            balanceSetLabel.append(trainSetCountLabel[i])
            bound.append(allBound[i])

    return balanceSet, balanceSetLabel, bound


#get balanced dataset, with left returned, used for unlabeled data for iteration
def balanceNumAdd(balanceNum, trainSetData, trainSetCountLabel, allBound):
    labelledNum = 0
    zeroNum = 0

    balanceSet = []
    balanceSetLabel = []
    bound = []

    restSet = []
    restSetLabel = []
    restBound = []

    for i in range(len(trainSetData)):
        if trainSetCountLabel[i] > 0 and labelledNum < balanceNum:
            labelledNum = labelledNum + 1
            balanceSet.append(trainSetData[i])
            balanceSetLabel.append(trainSetCountLabel[i])
            bound.append(allBound[i])

        if trainSetCountLabel[i] > 0 and labelledNum >= balanceNum:
            restSet.append(trainSetData[i])
            restSetLabel.append(trainSetCountLabel[i])
            restBound.append(allBound[i])

        if trainSetCountLabel[i] == 0 and zeroNum < balanceNum:
            zeroNum = zeroNum + 1
            balanceSet.append(trainSetData[i])
            balanceSetLabel.append(trainSetCountLabel[i])
            bound.append(allBound[i])

        if trainSetCountLabel[i] == 0 and zeroNum >= balanceNum:
            restSet.append(trainSetData[i])
            restSetLabel.append(trainSetCountLabel[i])
            restBound.append(allBound[i])



    return balanceSet, balanceSetLabel, bound, restSet,restSetLabel,restBound

def balanceNumAdd_all(balanceNum, trainSetData, trainSetCountLabel, allBound):
    label0 = 0
    label1 = 0
    label2 = 0
    label3 = 0
    label4 = 0
    label5 = 0


    balanceSet = []
    balanceSetLabel = []
    bound = []

    restSet = []
    restSetLabel = []
    restBound = []

    for i in range(len(trainSetData)):
        if trainSetCountLabel[i] == 0 and label0 < balanceNum:
            label0 = label0 + 1
            balanceSet.append(trainSetData[i])
            balanceSetLabel.append(trainSetCountLabel[i])
            bound.append(allBound[i])

        if trainSetCountLabel[i] == 0 and label0 >= balanceNum:
            restSet.append(trainSetData[i])
            restSetLabel.append(trainSetCountLabel[i])
            restBound.append(allBound[i])

        if trainSetCountLabel[i] == 1 and label1 < balanceNum:
            label1 = label1 + 1
            balanceSet.append(trainSetData[i])
            balanceSetLabel.append(trainSetCountLabel[i])
            bound.append(allBound[i])

        if trainSetCountLabel[i] == 1 and label1 >= balanceNum:
            restSet.append(trainSetData[i])
            restSetLabel.append(trainSetCountLabel[i])
            restBound.append(allBound[i])

        if trainSetCountLabel[i] == 2 and label2 < balanceNum:
            label2 = label2 + 1
            balanceSet.append(trainSetData[i])
            balanceSetLabel.append(trainSetCountLabel[i])
            bound.append(allBound[i])

        if trainSetCountLabel[i] == 2 and label2 >= balanceNum:
            restSet.append(trainSetData[i])
            restSetLabel.append(trainSetCountLabel[i])
            restBound.append(allBound[i])

        if trainSetCountLabel[i] == 3 and label3 < balanceNum:
            label3 = label3 + 1
            balanceSet.append(trainSetData[i])
            balanceSetLabel.append(trainSetCountLabel[i])
            bound.append(allBound[i])

        if trainSetCountLabel[i] == 3 and label3 >= balanceNum:
            restSet.append(trainSetData[i])
            restSetLabel.append(trainSetCountLabel[i])
            restBound.append(allBound[i])

        if trainSetCountLabel[i] == 4 and label4 < balanceNum:
            label4 = label4 + 1
            balanceSet.append(trainSetData[i])
            balanceSetLabel.append(trainSetCountLabel[i])
            bound.append(allBound[i])

        if trainSetCountLabel[i] == 4 and label4 >= balanceNum:
            restSet.append(trainSetData[i])
            restSetLabel.append(trainSetCountLabel[i])
            restBound.append(allBound[i])

        if trainSetCountLabel[i] >= 5  and label5 < balanceNum:
            label5 = label5 + 1
            balanceSet.append(trainSetData[i])
            balanceSetLabel.append(trainSetCountLabel[i])
            bound.append(allBound[i])

        if trainSetCountLabel[i] >= 5 and label5 >= balanceNum:
            restSet.append(trainSetData[i])
            restSetLabel.append(trainSetCountLabel[i])
            restBound.append(allBound[i])




    return balanceSet, balanceSetLabel, bound, restSet,restSetLabel,restBound

#check the data distribution
def countLabelBalanced(tld):
    count = len(tld)
    myset = set(tld)
    a = []
    for item in myset:
        print((item, tld.count(item)))


# return balance number of the dataset
def countLabel(tld):
    a = []
    count = len(tld)
    myset = set(tld)
    for item in myset:
        ai = (item, tld.count(item))
        a.append(ai)

    balance = 0
    for item_t in a:
        if item_t[0] != 0:
            balance = balance + item_t[1]

    return balance

#get labels number and minimal number of labels,
def countAllLabelBalanced(tld):
    a = []
    count = len(tld)
    myset = set(tld)
    for item in myset:
        ai = tld.count(item)
        a.append(ai)

    return a, min(a)

# generate balanced set with all label number balanced
def AllLabelBlanced(number, trainSetData, trainSetCountLabel, allBound):
    a, balance = countAllLabelBalanced(trainSetCountLabel)
    count = np.zeros(len(a))

    balanceSet = []
    balanceSetLabel = []
    bound = []
    for i in range(len(trainSetData)):
        for j in range(0,len(a)):
            if count[j] < number and trainSetCountLabel[i] == j:
                count[j] = count[j] + 1
                balanceSet.append(trainSetData[i])
                balanceSetLabel.append(trainSetCountLabel[i])
                bound.append(allBound[i])

    return balanceSet,balanceSetLabel,bound


#concat dataset and label, deepcopy, not change original ones
def concatData(t1,t2,t1l, t2l):
    #print(len(t1), len(t1l))
    t3 = copy.deepcopy(t1)
    t3l = copy.deepcopy(t1l)

    for i in range(len(t2)):
        t3.append(t2[i])
        t3l.append(t2l[i])

    #print(len(t1), len(t1l))

    return t3, t3l

#concat dataset, label and boundary
def concatDataWithBoundary(t1,t2,t1l, t2l, t1b, t2b):
    #print(len(t1), len(t1l))
    t3 = copy.deepcopy(t1)
    t3l = copy.deepcopy(t1l)
    t3b = copy.deepcopy(t1b)

    for i in range(len(t2)):

        t3.append(t2[i])
        t3l.append(t2l[i])
        t3b.append(t2b[i])


    #print(len(t1), len(t1l))

    return t3, t3l, t3b

#check for wells in time-series
def timeSeries(b1, b2, l1, l2):#b1, l1 for real labelled data
    for i in range(len(b1)):
        for j in range(len(b2)):
            if abs(b1[i][0]-b2[j][0]) <= 2 and abs(b1[i][1]-b2[j][1]) <= 2:
                if l1[i] == 0 and l2[j] != 0:
                    l2[j] = 0

