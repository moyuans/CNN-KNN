import csv
import numpy as np
from scipy import misc
from PIL import Image, ImageFilter
import random


def loadEntireImage(entire_path):
    img = Image.open(entire_path)
    return img

#get boundary of a well from csv
def loadBoundary(ai):
    oneTest = ai
    x1 = 0
    y1 = 0
    x = round(float(oneTest[0]))
    y = round(float((oneTest[1])))
    w = round(float((oneTest[2])))
    h = round(float((oneTest[3])))

    if x + 54 <= 1080 and y + 54 <= 1280:
        x1 = x + 54
        y1 = y + 54  # fix well size to get trainSetData balanced, size for an array in it

    return ([x, y, x1, y1])


# get boundary of wells for a frame
def loadBoundaryW(path):  # new

    a = []
    csv_reader = csv.reader(open(path))
    for row in csv_reader:
        a.append(row)

    return a


#get coordinates of cells of a frame
def loadCoordinateW(path):  # new

    a = []
    csv_reader = csv.reader(open(path))
    for row in csv_reader:
        a.append(row)

    arrayX = []
    arrayY = []

    for i in range(0, len(a)):
        xc = float(a[i][0])  # or int
        yc = float(a[i][1])

        arrayX.append(xc)
        arrayY.append(yc)

    return arrayX, arrayY


# coordinates of cells for a well in csv in string format
def loadCoordinate(path, bi):
    a = []
    csv_reader = csv.reader(open(path))
    for row in csv_reader:
        a.append(row)

    arrayX = []
    arrayY = []

    x = float(bi[0])
    y = float(bi[1])
    w = float(bi[2])
    h = float(bi[3])

    for i in range(0, len(a)):
        xc = float(a[i][0])
        yc = float(a[i][1])
        if xc > x and xc < x + w:  # need well validation check? or not?
            if yc > y and yc < y + h:
                arrayX.append(xc)
                arrayY.append(yc)

    return arrayX, arrayY


def rgbToInteger(r, g, b):  # no need to get value in M
    return r * 256 * 256 + g * 256 + b


# calculate the label of a well
def countCell(cx):
    return len(cx)


#generate all wells from some annotated frames, the output set is not balanced
def generateTrainSetBalanced(entireImgPath, boundaryPath, coordinatePath, numberOfImage):
    trainData = []
    trainLabelCount = []
    allBound = []

    for imageNumber in range(numberOfImage[0], numberOfImage[1] + 1):
        entireImg = loadEntireImage(entireImgPath + str(imageNumber) + ".jpeg")
        boundaryW = loadBoundaryW(boundaryPath + str(imageNumber) + ".csv")

        for i in range(len(boundaryW)):  # for a single well
            boundary = loadBoundary(boundaryW[i])
            cxx, cyy = loadCoordinate(coordinatePath + str(imageNumber) + ".csv", boundaryW[i])
            img = entireImg.crop(boundary)
            rgb = []
            for k in range(len(img.getdata())):
                rgb.append(rgbToInteger(img.getdata()[k][0], img.getdata()[k][1], img.getdata()[k][2]))

            count = countCell(cxx)

            if boundary[2] != 0:
                trainData.append(rgb)
                trainLabelCount.append(count)
                allBound.append(boundary)

    return trainData, trainLabelCount, allBound


#generate all wells from unlabelled frames
def generateSetBalanced(entireImgPath, boundaryPath, numberOfImage):
    trainData = []
    boundaryC = []

    for imageNumber in range(numberOfImage[0], numberOfImage[1] + 1):
        entireImg = loadEntireImage(entireImgPath + str(imageNumber) + ".jpeg")
        boundaryW = loadBoundaryW(boundaryPath + str(imageNumber) + ".csv")

        for i in range(len(boundaryW)):  # for a single well
            boundary = loadBoundary(boundaryW[i])

            img = entireImg.crop(boundary)
            rgb = []
            for k in range(len(img.getdata())):
                rgb.append(rgbToInteger(img.getdata()[k][0], img.getdata()[k][1], img.getdata()[k][2]))

            if (boundary[2] != 0):
                trainData.append(rgb)
                boundaryC.append(boundary)

    #print(len(trainData))

    return trainData, boundaryC

###################
#image augmentation
###################
def generateTrainP(entireImgPath, boundaryPath, coordinatePath, numberOfImage): #for image directly
    imgs = []
    count = []
    bound = []
    for imageNumber in range(numberOfImage[0], numberOfImage[1] + 1):
        entireImg = loadEntireImage(entireImgPath + str(imageNumber) + ".jpeg")
        boundaryW = loadBoundaryW(boundaryPath + str(imageNumber) + ".csv")

        for i in range(len(boundaryW)):  # for a single well
            boundary = loadBoundary(boundaryW[i])
            if coordinatePath != None:
                cxx, cyy = loadCoordinate(coordinatePath + str(imageNumber) + ".csv", boundaryW[i])

            img = entireImg.crop(boundary)
            if boundary[2] != 0:
                imgs.append(img)
                if coordinatePath != None:
                    countx = countCell(cxx)
                    count.append(countx)
                bound.append(boundary)

    if len(count) != 0:
        return imgs, count, bound
    else:
        return imgs, bound, np.zeros(len(imgs))




def imgToArray(img):
    rgb = []
    for k in range(len(img.getdata())):
        rgb.append(rgbToInteger(img.getdata()[k][0], img.getdata()[k][1], img.getdata()[k][2]))

    return rgb

def sp_noise(image,prob): #0.3
    data = imgToArray(image)
    output = data
    thres = 1 - prob
    for i in range(len(data)):
        rdn = random.random()
        if rdn < prob:
            output[i] = 0
        elif rdn > thres:
            output[i] = 16777215
        else:
            output[i] = data[i]

    return output

    #return np.reshape(np.asarray(output), 54)


def ImgAug10(img):
    data = []

    data0 = imgToArray(img)
    data.append(data0)

    #path = '/Users/sunmoyuan1/Desktop/'

    #img.save('/Users/sunmoyuan1/Desktop/original.jpeg')

    out1 = img.transpose(Image.FLIP_LEFT_RIGHT)
    #out1.save(path + 'out1.jpeg')
    data1 = imgToArray(out1)
    data.append(data1)



    out2 = img.transpose(Image.FLIP_TOP_BOTTOM)
    #out2.save(path + 'out2.jpeg')
    data2 = imgToArray(out2)
    data.append(data2)

    out3 = img.transpose(Image.ROTATE_90)
    #out3.save(path + 'out3.jpeg')
    data3 = imgToArray(out3)
    data.append(data3)

    out4 = img.transpose(Image.ROTATE_180)
    #out4.save(path + 'out4.jpeg')
    data4 = imgToArray(out4)
    data.append(data4)

    out5 = img.transpose(Image.ROTATE_270)
    #out5.save(path + 'out5.jpeg')
    data5 = imgToArray(out5)
    data.append(data5)

    out6 = img.filter(ImageFilter.GaussianBlur(radius=0.5))
    #out6.save(path + 'out6.jpeg')
    data6 = imgToArray(out6)
    data.append(data6)

    out7 = img.filter(ImageFilter.GaussianBlur(radius=1))
    #out7.save(path + 'out7.jpeg')
    data7 = imgToArray(out7)
    data.append(data7)

    data8 = sp_noise(img,0.001)
    #td8 = np.asarray(data8).reshape(53, 53)
    #path = '/Users/sunmoyuan1/Desktop/out8.jpeg'
    #misc.imsave(path, td8)
    data.append(data8)

    data9 = sp_noise(img,0.002)
    #td9 = np.asarray(data9).reshape(53, 53)
    #path = '/Users/sunmoyuan1/Desktop/out9.jpeg'
    #misc.imsave(path, td9)
    data.append(data9)

    data10 = sp_noise(img, 0.003)
    #td10 = np.asarray(data10).reshape(53, 53)
    #path = '/Users/sunmoyuan1/Desktop/out10.jpeg'
    #misc.imsave(path, td10)
    data.append(data10)

    return data


