"""
references from:
    
http://blog.csdn.net/yewei11/article/details/50329499
    
http://deeplearning.net/tutorial/lenet.html
"""

import pickle
import numpy
import theano
import theano.tensor as T
from theano.tensor.nnet import conv
from theano.tensor.signal import downsample
import math


def load_params(params_file):
    f = open(params_file, 'rb')
    layer0_params = pickle.load(f)
    layer1_params = pickle.load(f)
    layer2_params = pickle.load(f)
    layer3_params = pickle.load(f)
    f.close()
    return layer0_params, layer1_params, layer2_params, layer3_params


def load_data(Data, Label):
    test_data = numpy.array(Data)
    test_label = numpy.array(Label)
    return test_data, test_label


class LogisticRegression(object):
    def __init__(self, input, params_W, params_b, n_in, n_out):
        self.W = params_W
        self.b = params_b
        self.p_y_given_x = T.nnet.softmax(T.dot(input, self.W) + self.b)
        self.y_pred = T.argmax(self.p_y_given_x, axis=1)
        self.params = [self.W, self.b]

    def negative_log_likelihood(self, y):
        return -T.mean(T.log(self.p_y_given_x)[T.arange(y.shape[0]), y])

    def errors(self, y):
        if y.ndim != self.y_pred.ndim:
            raise TypeError(
                'y should have the same shape as self.y_pred',
                ('y', y.type, 'y_pred', self.y_pred.type)
            )
        if y.dtype.startswith('int'):
            return T.mean(T.neq(self.y_pred, y))
        else:
            raise NotImplementedError()


class LinearRegression(object):
    def __init__(self, input, params_W, params_b, n_in, n_out):
        self.W = params_W
        self.b = params_b
        self.p_y_given_x = T.dot(input, self.W) + self.b
        self.y_pred = self.p_y_given_x[:, 0]

        self.params = [self.W, self.b]

    def linear_likelihood(self, y, number):

        return T.sum(T.pow(self.y_pred - y, 2)) / (2 * number)

    def errors(self, y):
        if y.ndim != self.y_pred.ndim:
            raise TypeError(
                'y should have the same shape as self.y_pred',
                ('y', y.type, 'y_pred', self.y_pred.type)
            )
        if y.dtype.startswith('int'):
            return T.sum(T.pow(self.y_pred - y, 2))

        else:
            raise NotImplementedError()


class HiddenLayer(object):
    def __init__(self, input, params_W, params_b, n_in, n_out,
                 activation=T.tanh):
        self.input = input
        self.W = params_W
        self.b = params_b

        lin_output = T.dot(input, self.W) + self.b
        self.output = (
            lin_output if activation is None
            else activation(lin_output)
        )
        self.params = [self.W, self.b]


class LeNetConvPoolLayer(object):
    def __init__(self, input, params_W, params_b, filter_shape, image_shape, poolsize=(2, 2)):
        assert image_shape[1] == filter_shape[1]
        self.input = input
        self.W = params_W
        self.b = params_b

        conv_out = conv.conv2d(
            input=input,
            filters=self.W,
            filter_shape=filter_shape,
            image_shape=image_shape
        )

        pooled_out = downsample.max_pool_2d(
            input=conv_out,
            ds=poolsize,
            ignore_border=True
        )
        self.output = T.tanh(pooled_out + self.b.dimshuffle('x', 0, 'x', 'x'))
        self.params = [self.W, self.b]




def use_CNN(dataSet, labelSet, params_file, choice, printSwitch):

    data, label = load_data(dataSet, labelSet)
    data_num = data.shape[0]  # how many data


    layer0_params, layer1_params, layer2_params, layer3_params = load_params(params_file)
    #     layer0_params,layer1_params,layer4_params,layer2_params,layer3_params=load_params(params_file)




    x = T.matrix('x')

    width = 54
    height = 54

    nkerns = [5, 10]
    fullyOutputNumber = 1000

    layer1_conv = 5
    layer2_conv = 5

    layer0_input = x.reshape((data_num, 1, width, height))
    layer0 = LeNetConvPoolLayer(
        input=layer0_input,
        params_W=layer0_params[0],
        params_b=layer0_params[1],
        image_shape=(data_num, 1, width, height),
        filter_shape=(nkerns[0], 1, layer1_conv, layer1_conv),
        poolsize=(2, 2)
    )

    width1 = math.floor((width - layer1_conv + 1) / 2)


    layer1 = LeNetConvPoolLayer(
        input=layer0.output,
        params_W=layer1_params[0],
        params_b=layer1_params[1],
        image_shape=(data_num, nkerns[0], width1, width1),
        filter_shape=(nkerns[1], nkerns[0], layer2_conv, layer2_conv),
        poolsize=(2, 2)
    )

    layer2_input = layer1.output.flatten(2)

    width2 = math.floor((width1 - layer2_conv + 1) / 2)

    layer2 = HiddenLayer(
        input=layer2_input,
        params_W=layer2_params[0],
        params_b=layer2_params[1],

        n_in=nkerns[1] * width2 * width2,
        n_out=fullyOutputNumber,
        activation=T.tanh
    )

    if (choice == "linear_count"):
        layer3 = LinearRegression(input=layer2.output, params_W=layer3_params[0], params_b=layer3_params[1],
                                  n_in=fullyOutputNumber, n_out=1)




    f = theano.function(
        [x],
        layer3.y_pred
    )


    pred = f(data)


    wrongList = []


    for i in range(data_num):
        try:
            if label[i] != math.floor(pred[i]) or pred[i] == numpy.nan:
                wrongList.append(i)
                if (printSwitch == True):
                    print('picture: %i is %i, mis-predicted as  %i' % (i, label[i], pred[i]))
        except:
            wrongList.append(i)

    return label, pred, wrongList



