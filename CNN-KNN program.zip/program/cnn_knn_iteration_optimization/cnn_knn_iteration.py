import data_generation
import general
import cnn_train
import cnn_test
import abs
from scipy.stats.stats import pearsonr
import numpy as np
import math
from sklearn.neighbors import KNeighborsClassifier
from scipy import misc
from sklearn.metrics import mean_squared_error

import csv
import copy

import pylab
import matplotlib.pyplot as plt

entireImage = '/Users/sunmoyuan1/Desktop/original_jpeg/'
boundary = '/Users/sunmoyuan1/Desktop/wells/'
coordinate = '/Users/sunmoyuan1/Desktop/coordinate/c'

uImages = '/Users/sunmoyuan1/Desktop/u_jpeg/'
uboundary = '/Users/sunmoyuan1/Desktop/n_wells/'


def ScatterFig(predict, true, number, title):
    pylab.rcParams['figure.figsize'] = (10.0, 10.0)
    img = plt.scatter(true, predict, color='black')
    plt.ylabel('Predicted Number Of Cells')
    plt.xlabel('True Number Of Cells')
    plt.title(title)
    plt.axis('on')
    fig = plt.gcf()

    fig.savefig('/Users/sunmoyuan1/Desktop/' + str(number) + '.png', dpi=100)
    plt.show(img)

def gt_init(numberOfImages, entireImage, boundary, coordinate, number):
    trainSetData, trainSetCountLabel, allBound = data_generation.generateTrainSetBalanced(entireImage, boundary, coordinate, numberOfImages)
    trainD, trainL, bound = general.balanceNum(number, trainSetData, trainSetCountLabel, allBound)

    return trainD, trainL, bound

def ud_init(numberOfImages, uImages, uboundary):
    td, btd = data_generation.generateSetBalanced(uImages, uboundary, numberOfImages)
    tld = np.zeros(len(td)).tolist()

    return td, tld, btd

def getThreshold(Data, Label): 

    y_true, y_pred, wrongID = cnn_test.use_CNN(Data, Label, 'linear_count_params.pkl','linear_count', False)
    pearson = pearsonr(y_true, y_pred)
    rmse = math.sqrt(mean_squared_error(y_pred,y_true))
    accuracy = (len(y_true) - len(wrongID))/len(y_true)

    return pearson, rmse,accuracy

def getThreshold2(Data, Label, number, title):

    y_true, y_pred, wrongID = cnn_test.use_CNN(Data, Label, 'linear_count_params.pkl','linear_count', False)
    ScatterFig(y_pred, y_true, number, title)
    pearson = pearsonr(y_true, y_pred)
    rmse = math.sqrt(mean_squared_error(y_pred,y_true))
    accuracy = (len(y_true) - len(wrongID))/len(y_true)

    return pearson, rmse,accuracy


def getAbs(Data, Label):
    y_abs = abs.abs(Data, Label, 'linear_count_params.pkl', 'linear_count')

    return y_abs

def getTrainData_new(neighbours, trainD, uD, trainL, bound, ubound, abs_t, abs_u, number_add, confidence_threshold):
    knn = KNeighborsClassifier(n_neighbors=neighbours)
    x1 = abs_t
    x1_b = bound
    y1 = trainL

    knn.fit(x1, y1)

    x2 = abs_u
    x2_b = ubound
    #print('abs_u length is: ' + str(len(x2)))

    y2 = knn.predict(x2)
    prob = knn.predict_proba(x2)

    #print('abs_u_y length is: ' + str(len(y2)))

    td = []
    tdy = []
    tboundary = []

    utd = []
    utdy = []
    utboundary = []
    for j in range(len(y2)):
        if max(prob[j]) > confidence_threshold:
            td.append(uD[j])
            tdy.append(y2[j])
            tboundary.append(x2_b[j])
        else:
            utd.append(uD[j])
            utdy.append(y2[j])
            utboundary.append(x2_b[j])

    #print('td length is: ' + str(len(td)))
    # utd not have those for sure but not included in the final balance set
    #print('utd length is: ' + str(len(utd)))


    general.timeSeries(x1_b, tboundary, trainL, tdy)

    balance = general.countLabel(tdy)
    print(balance)


    if balance < number_add:
        x_add, y_add, b_add, restSet,restSetLabel,restBound = general.balanceNumAdd(balance, td, tdy, tboundary)
    else:
        x_add, y_add, b_add, restSet,restSetLabel,restBound = general.balanceNumAdd(number_add, td, tdy, tboundary)

    trainD1, trainL1, bound1 = general.concatDataWithBoundary(trainD, x_add, trainL, y_add, x1_b, b_add)

    if len(restSet) != 0:
        utd, utdy, utboundary = general.concatDataWithBoundary(utd, restSet, utdy, restSetLabel, utboundary, restBound) #except the labelled ones for UL



    return trainD1, trainL1, bound1, utd, utdy, utboundary, balance

"""
set parameters for this CNN-KNN model:

balanceNum * 2 is the size the confident set put into the training set iteratively

for gt_init(), n * 2 is size of trainset

to change CNN parameters see cnn_train.py
"""
iteration_limit = 5
K_nearest_neighbours = 5
confidence_threshold = 0.5
balanceNum = 20

trainD, trainL, bound = gt_init([1, 6], entireImage, boundary, coordinate, 400)
testD, testL, testbound = gt_init([7, 12], entireImage, boundary, coordinate, 500)
ud, uld, ubound = ud_init([1, 12], uImages, uboundary)

cnn_train.train_CNN(54, 54, 5000, 'linear_count', trainD, trainL, 0.000005)
pearson, rmse, accuracy = getThreshold2(testD, testL, 800, 'CNN Only')

train_abs = getAbs(trainD, trainL)
u_abs = getAbs(ud, uld)
count = 0
while count < iteration_limit:
    trainD, trainL, bound, utd1, utdy1, ubound, balance = getTrainData_new(K_nearest_neighbours, trainD, ud, trainL, bound, ubound,
                                                                           train_abs, u_abs, balanceNum, confidence_threshold)

    cnn_train.train_CNN(54, 54, 5000, 'linear_count', trainD, trainL, 0.000005)

    train_abs = getAbs(trainD, trainL)
    u_abs = getAbs(utd1, utdy1)
    count = count + 1


print()
print('the CNN only model Pearson, RMSE is: ')
print(pearson[0], rmse)
print()
print('the CNN-KNN model Pearson, RMSE is: ')
pearson1, rmse1, accuracy1 = getThreshold2(testD, testL, 1000, 'CNN-KNN')
print(pearson1[0], rmse1)

